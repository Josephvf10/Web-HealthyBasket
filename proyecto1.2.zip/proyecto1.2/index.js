document.getElementById("forgot-password-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita el envío del formulario

    let email = document.getElementById("email").value.trim();

    if (email === "") {
        alert("Por favor, ingrese su correo electrónico.");
        return;
    }

    alert("Si el correo está registrado, recibirás un enlace para recuperar tu contraseña.");
});
